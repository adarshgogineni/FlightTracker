package com.flighttracker;

public class Airline {
	private String airlineId;

	public String getAirlineId() {
		return airlineId;
	}

	public void setAirportId(String airlineId) {
		this.airlineId = airlineId;
	}
}
