package com.flighttracker;

public class Airport {
	
	private String airportId;

	public String getAirportId() {
		return airportId;
	}

	public void setAirportId(String airportId) {
		this.airportId = airportId;
	}

}
